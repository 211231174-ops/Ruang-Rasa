RUANG RASA WEBSITE

Cara membuka:
1. Ekstrak file ZIP ini.
2. Buka folder ruang_rasa_website.
3. Klik dua kali index.html untuk melihat website di browser.

Catatan:
- Website dibuat sebagai landing page responsif.
- Tombol Instagram diarahkan ke @ruangrasa.id sesuai materi visual yang diberikan.
- Detail menu, harga, alamat, dan pemesanan belum dicantumkan karena belum ada di brief.
- Website memakai Google Fonts; koneksi internet diperlukan agar font tampil sesuai desain.
